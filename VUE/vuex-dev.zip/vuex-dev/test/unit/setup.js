import 'babel-polyfill'
import Vue from 'vue/dist/vue.common.js'
import Vuex from '../../dist/vuex.common.js'

Vue.use(Vuex)
