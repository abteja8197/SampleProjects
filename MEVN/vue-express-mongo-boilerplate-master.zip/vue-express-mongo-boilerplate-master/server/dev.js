"use strict";

require("nodejs-dashboard");
require("./index");