"use strict";

module.exports = {
	counter: 0
};