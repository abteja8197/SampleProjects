"use strict";

import style from "../scss/frontend.scss";

console.log("Frontend loaded!");

