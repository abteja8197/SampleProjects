<template lang="pug">
	.logo
		a.nav-item(href="#")
			span 
				strong VEM
				| App
</template>

<script>

	export default {

	};
	
</script>

<style lang="scss">
</style>