export const LOAD 			= "LOAD";
export const ADD 			= "ADD";
export const SELECT			= "SELECT";
export const CLEAR_SELECT	= "CLEAR_SELECT";
export const UPDATE			= "UPDATE";
export const REMOVE			= "REMOVE";