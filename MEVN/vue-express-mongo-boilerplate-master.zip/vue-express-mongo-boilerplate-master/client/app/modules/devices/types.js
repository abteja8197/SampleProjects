module.exports = {

	deviceTypes: [
		{ id: "rasperry", name: "Raspberry" },
		{ id: "odroid", name: "ODroid" },
		{ id: "nanopi", name: "NanoPI" },
		{ id: "pc", name: "PC" }	
	]
	
};