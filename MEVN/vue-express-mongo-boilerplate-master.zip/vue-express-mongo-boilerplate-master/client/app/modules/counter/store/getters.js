export function count(state) {
	return state.count;
}
