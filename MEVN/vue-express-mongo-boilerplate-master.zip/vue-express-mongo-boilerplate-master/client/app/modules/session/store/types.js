export const SEARCH						= "SEARCH";
export const ADD_NOTIFICATION 			= "ADD_NOTIFICATION";
export const ADD_MESSAGE 				= "ADD_MESSAGE";
export const SET_USER	 				= "SET_SESSION_USER";
