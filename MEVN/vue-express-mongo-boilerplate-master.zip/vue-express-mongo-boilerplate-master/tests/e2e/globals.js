"use strict";

module.exports = {

	"waitForConditionTimeout": 10000
	
};
