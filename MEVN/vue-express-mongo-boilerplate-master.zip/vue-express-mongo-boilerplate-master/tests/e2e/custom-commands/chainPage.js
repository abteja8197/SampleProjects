"use strict";

module.exports.command = function(page) {
	return page;
};
