"use strict";

if (!global._app)
	global._app = require("../server");

module.exports = global._app;