<template>
  <div class="about">
    <h1 class="display3">About Us</h1>
    <div class="card p-3">
      <h4>We are Codebook Inc.</h4>
      <p>We are happy to help you in learning the projects.</p>
      <span>Business Email:</span> mauryanarendra09@gmail.com
    </div>
  </div>
</template>
