'use strict';

import React from 'react';

require('styles/molecules/SaveList.css');

class SaveListComponent extends React.Component {
  render() {
    return (
      <div className="savelist-component">
        Please edit src/components/molecules//SaveListComponent.js to update this component!
      </div>
    );
  }
}

SaveListComponent.displayName = 'MoleculesSaveListComponent';

// Uncomment properties you need
// SaveListComponent.propTypes = {};
// SaveListComponent.defaultProps = {};

export default SaveListComponent;
