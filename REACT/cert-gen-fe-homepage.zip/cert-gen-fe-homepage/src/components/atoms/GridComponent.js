'use strict';

import React from 'react';

require('styles/atoms/Grid.css');

class GridComponent extends React.Component {
  render() {
    return (
      <div className="grid-component">
        Please edit src/components/atoms//GridComponent.js to update this component!
      </div>
    );
  }
}

GridComponent.displayName = 'AtomsGridComponent';

// Uncomment properties you need
// GridComponent.propTypes = {};
// GridComponent.defaultProps = {};

export default GridComponent;
