'use strict';

import React from 'react';

require('styles/organisms/Dropdown.css');

class DropdownComponent extends React.Component {
  render() {
    return (
      <div className="dropdown-component">
        Please edit src/components/organisms//DropdownComponent.js to update this component!
      </div>
    );
  }
}

DropdownComponent.displayName = 'OrganismsDropdownComponent';

// Uncomment properties you need
// DropdownComponent.propTypes = {};
// DropdownComponent.defaultProps = {};

export default DropdownComponent;
